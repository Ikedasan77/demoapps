from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib import messages
from .forms import AnswerForm
import random

def generate_quiz():
    num1 = random.randint(1, 10)
    num2 = random.randint(1, 10)
    operator = random.choice(['+', '-'])

    if operator == '+':
        correct_answer = num1 + num2
    else:
        correct_answer = num1 - num2

    question = f"{num1} {operator} {num2} = ?"
    
    return {
        'question': question,
        'correct_answer': correct_answer
    }

def quiz_view(request):
    if 'correct_count' not in request.session:
        request.session['correct_count'] = 0
        request.session['incorrect_count'] = 0
        request.session['question_number'] = 1
    
    if request.method == 'POST':
        form = AnswerForm(request.POST)
        if form.is_valid():
            user_answer = form.cleaned_data['answer']
            correct_answer = request.session.get('correct_answer')

            if user_answer == correct_answer:
                request.session['correct_count'] += 1
            else:
                request.session['incorrect_count'] += 1

            request.session['question_number'] += 1
            
            if request.session['question_number'] > 10:
                return redirect('result')

        # フォームが無効だった場合でもクイズを生成する
        quiz = generate_quiz()
        request.session['correct_answer'] = quiz['correct_answer']
    else:
        quiz = generate_quiz()
        request.session['correct_answer'] = quiz['correct_answer']
        form = AnswerForm()

    return render(request, 'quiz/quiz.html', {
        'form': form,
        'question': quiz['question'],
        'question_number': request.session['question_number']
    })


def result_view(request):
    correct_count = request.session.get('correct_count', 0)
    incorrect_count = request.session.get('incorrect_count', 0)
    
    if correct_count >= 8:
        comment = "素晴らしい！"
    elif correct_count >= 5:
        comment = "良くできました。"
    else:
        comment = "もっと練習が必要です。"

    # セッションをリセット
    request.session.flush()

    return render(request, 'quiz/result.html', {
        'correct_count': correct_count,
        'incorrect_count': incorrect_count,
        'comment': comment
    })

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'アカウントが作成されました！')
            return redirect('quiz')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})
