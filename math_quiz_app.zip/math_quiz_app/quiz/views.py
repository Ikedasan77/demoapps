from django.shortcuts import render, redirect
from .forms import AnswerForm
import random

def generate_quiz():
    num1 = random.randint(1, 10)
    num2 = random.randint(1, 10)
    operator = random.choice(['+', '-'])

    if operator == '+':
        correct_answer = num1 + num2
    else:
        correct_answer = num1 - num2

    question = f"{num1} {operator} {num2} = ?"
    
    return {
        'question': question,
        'correct_answer': correct_answer
    }

def quiz_view(request):
    if request.method == 'POST':
        form = AnswerForm(request.POST)
        if form.is_valid():
            user_answer = form.cleaned_data['answer']
            correct_answer = request.session.get('correct_answer')
            if user_answer == correct_answer:
                result = "Correct!"
                explanation = f"The correct answer is {correct_answer}."
            else:
                result = "Incorrect."
                explanation = f"The correct answer was {correct_answer}."

            return render(request, 'quiz/result.html', {
                'result': result,
                'explanation': explanation
            })
    else:
        quiz = generate_quiz()
        request.session['correct_answer'] = quiz['correct_answer']
        form = AnswerForm()

    return render(request, 'quiz/quiz.html', {
        'form': form,
        'question': quiz['question']
    })
