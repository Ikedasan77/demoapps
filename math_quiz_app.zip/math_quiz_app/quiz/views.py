import random
from django.shortcuts import render

def generate_quiz():
    num1 = random.randint(1, 100)
    num2 = random.randint(1, 100)
    operator = random.choice(['+', '-'])
    
    if operator == '+':
        correct_answer = num1 + num2
    else:
        correct_answer = num1 - num2

         # choicesリストを初期化
    choices = []
    
    # 正解とランダムな選択肢を追加
    choices = [correct_answer + random.randint(-10, 10) for _ in range(3)]
    choices.append(correct_answer)
    random.shuffle(choices)
    
    question = f"{num1} {operator} {num2} = ?"
    
    return {
        'question': question,
        'choices': choices,
        'correct_answer': correct_answer
    }

def quiz_view(request):
    quiz = generate_quiz()
    user_answer = request.GET.get('answer')
    
    if user_answer:
        user_answer = int(user_answer)
        if user_answer == quiz['correct_answer']:
            result = "正解です！"
        else:
            result = f"不正解です。正しい答えは {quiz['correct_answer']} です。"
    else:
        result = None
    
    return render(request, 'quiz/quiz.html', {'quiz': quiz, 'result': result})
